//
//  K3DatePickerViewController.swift
//  DatePickerUtils
//
//  Created by Karan Kumar Kanathe on 08/09/19.
//  Copyright © 2019 Karan Kanathe. All rights reserved.
//

import UIKit

class K3DatePickerView: UIView {
    
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var containerView : UIView!
    @IBOutlet var btnCancel : UIButton!
    
    static let shared = K3DatePickerView()
    
    var selected : ((Date) -> Void)?
    
    var mode : UIDatePicker.Mode = .dateAndTime

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    func setup(){
        Bundle.main.loadNibNamed("K3DatePickerView", owner: self, options: nil)
        addSubview(containerView)
        containerView.bounds = UIScreen.main.bounds
        containerView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        containerView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        
    }
    
    func present(){
        datePicker.datePickerMode = mode
        UIApplication.shared.keyWindow?.addSubview(containerView)
    }
    
    func dismiss(){
        containerView.removeFromSuperview()
    }
    
    @IBAction func btnOkPressed(_ sender : UIButton){
        selected?(datePicker.date)
    }
    
    @IBAction func btnCancelPressed(_ sender: Any) {
        dismiss()
    }
}
